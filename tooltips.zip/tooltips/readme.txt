=== Wordpress Tooltips ===
Contributors: Tomas.zhu
Author URI: http://tomas.zhu.bz
Tags:tooltip,hover,link,bubble,image,nextgen,next-gen,photo,picture,image,popup,phrase,glossary,video,radio,shortcode
Requires at least: 2.0
Tested up to: 2.7
Stable tag: 1.0.1
you can use it for word,phrases,link,shortcode.You can add text,image,link,video,radio in tooltips,nextgen description will shown as tooltips

== Description ==
Plugin Name: Wordpress Tooltips<br>
Plugin Support URI: http://tomas.zhu.bz/wordpress-plugin-tooltips.html/<br>

Wordpress Tooltips is a simple & quick & light & powerful jQuery tooltips solution that allow you use tooltips for word,phrases,image,links,even shortcode, or next-gen description, wordpress menu..., and so on.
You can add text, image, link, video, radio in tooltips, it can be used as a glossary too. 

You can manage all keyword/content centrally in one admin panel easily and quickly. Just input keyword in keyword field and video/rideo/text/image/link in content field, everything will be o.k, for next-gen users,
you do not need to do anything, tooltips plugin will detected next-gen description and show it as a tooltips when hovering your next-gen images.

== Installation ==

1:Upload the Wordpress Tooltips plugin to your blog
2:Activate it 
3:edit keyword and content in tooltips menu

1, 2, 3: You're done!

== Screenshots ==

1: Front End 
2: Back End
== Frequently Asked Questions ==
FAQs can be found here: http://tomas.zhu.bz/wordpress-plugin-tooltips.html/

== Changelog ==

= Version 1.0.0 =

* Spell out that the license is GPLv2
* Finished the first version
* General code clean up

= Version 1.0.1 =
* More friendly in back end

== Download ==
http://wordpress.org/extend/plugins/wordpress-tooltips/